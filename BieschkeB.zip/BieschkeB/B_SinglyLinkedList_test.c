/*Brandon Bieschke
ECE 361 - Fall 2021 - HW 2
3a - Rewriting Karumanchi's Singly Linked List

Refactor Karumanchi�s SinglyLinkedList.c to separate the linked list ADT and main() into two files.
Create a header (.h) file for your newly minted linked list ADT.
This is the test.c, which includes the main() and the test call.
*/

#include "B_SinglyLinkedList.c"

int main() {
    SinglyLinkedList_test();

return 0;
}


int SinglyLinkedList_test(){
	struct listNode *head=NULL;
	insertInSinglyLinkedList(&head,5,5);
	insertInSinglyLinkedList(&head,2,5);
	printf("Elements in List:%d\n",singlyListLength(head));
	printSLList(head);
	deleteNodeFromLinkedList(&head,1);
	printSLList(head);
	return 0;
}
