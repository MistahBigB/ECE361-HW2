/*Brandon Bieschke
ECE 361 - Fall 2021 - HW 2
3b - Rewriting Karumanchi's Singly Linked List

Refactor Karumanchi�s SinglyLinkedList.c to separate the linked list ADT and main() into two files.
Create a header (.h) file for your newly minted linked list ADT.
This is the .h, with function prototypes.
Note line 21, where insertInSinglyLinkedList is now an int for error checking purposes.
*/

#include <stdio.h>
#include <stdlib.h>

struct listNode{
	int data;
	struct listNode *next;
};

void kreatorSLL();
int createSinglyLinkedList(struct listNode *head);
int singlyListLength(struct listNode *head);
int insertInSinglyLinkedList(struct listNode **head, int data, int pos);
void deleteNodeFromLinkedList(struct listNode **head, int pos);
void printSLList(struct listNode *head);
void singlyLinkedList_test(struct listNode *head);
