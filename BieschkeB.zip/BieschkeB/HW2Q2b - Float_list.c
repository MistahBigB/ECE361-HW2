/*Brandon Bieschke
ECE 361 - Fall 2021 - HW 2
Q2b - Recursive Floats

This program recursively finds the largest floating point number
between list[0] and list[n-1].
*/

#include <stdio.h>
#include <stdlib.h>

float max_recursive(float list[], int i, float previous_max, int n);

int main() {

    float list[20];
    float previous_max = 0;      //var to compare largest number with
    float max = 0;              //var to store the largest number
    int n = 0;              //var for the number of items in the list

    printf("Welcome! Please enter some floating point numbers: \n");
    printf("You can enter up to 20; just enter %d to stop.\n", 1);

    for (int i = 0; i < 20; i++ ) {     //users can input up to 20 numbers
        scanf("%f", &list[i]);
        n++;                            //increment number of items stored
        if (list[i] == 1)
            break;
    }

    n = n-1;        //set the length of the list to 1 less than the number entered
    printf("%d is the number of elements in the list\n", n);  //by the size of the first element

    printf("Ok! You entered: ");
    for (int i = 0; i < n; i++ ) {
        printf("%f ", list[i]);
    }

    previous_max = list[0];        //sets the number to compare to the largest number to the first number in the list
    //i = 0;

    max = max_recursive(&list, 0, previous_max, n);
    printf("\n%.4f is the largest number in this list", max);

    return 0;
}

 float max_recursive(float list[], int i, float previous_max, int n) {
    if (list[i] > previous_max) {       //set previous max to list's max value
        previous_max = list[i];
        }

    if (i == n-1)               //check to see if script at the end of the list
        return previous_max;
    else {                      //if we haven't, call the function again
        return max_recursive(list, i+1, previous_max, n);
      }
 }
