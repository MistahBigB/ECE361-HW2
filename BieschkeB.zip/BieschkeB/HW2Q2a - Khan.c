/*Brandon Bieschke
ECE 361 - Fall 2021 - HW 2
2a - Ghenghis Khan's centurians

This program describes how many leaders would have been necessary if
at every level of GK's army, 1 man was in charge of each power of 10.
*/

#include <stdio.h>
#include <stdlib.h>


int officers_supplied(int troops, int officers);

int main () {
    int troops = 0;     //var to store the number of base troopers
    int officers = 0;   //var to store the number of leaders
    int army = 0;       //var to store the numbers of base troopers and leaders

    printf("Welcome! In this version of history, Ghenghis Khan organized his army such that\n"
        "groups of 10 soldiers under a \�leader of 10\� (10 soldiers + 1 leader).\n"
        "Ten \"leaders of 10\� were under a \�leader of 100.\� Ten \�leaders of 100\� were under a \�leader of 1000,\" and so on.\n");

    printf("You are the new commander! How many troops do you bring to the Khan's glorious banner? ");
    scanf("%d", &troops);
    int soldiers = troops;

    printf("Outstanding! An increase of %d will surely help the Great Khan achieve victory!\n", troops);
    printf("You will need officers, however. The Khan furnishes officers based on powers of 10.\n");

    officers = officers_supplied(troops, officers);
    army = soldiers + officers;

    printf("The Great Khan has supplied you with %d officers for your %d troops, "
           "bringing the total of your command to %d. We ride!", officers, soldiers, army);

    return 0;
}

int officers_supplied(int troops, int officers) {
    //base case
    if (troops == 0)
        return officers;
    else if (troops <= 9) {
        officers += 1;
        return officers;
    }
    else {
    //recursive case
        troops = troops / 10;
        officers += troops;
        officers_supplied(troops, officers);
    }
}
