/*Brandon Bieschke
ECE 361 - Fall 2021 - HW 2
3a - Rewriting Karumanchi's Singly Linked List

Refactor Karumanchi�s SinglyLinkedList.c to separate the linked list ADT and main() into two files.
Create a header (.h) file for your newly minted linked list ADT.
This is the .c, which includes the struct and all of its associated functions.
Note line 24, where insertInSinglyLinkedList is now an int for error checking purposes, as it returns -1 for an error.
*/

#include "B_SinglyLinkedList.h"


int singlyListLength(struct listNode *head){
	int count=0;
	struct listNode *current=head;
	while(current!=NULL){
		count++;
		current=current->next;
	}
	return count;
}

int insertInSinglyLinkedList(struct listNode **head, int data, int pos){
	int k=1;
	struct listNode *q,*p;
	struct listNode *newNode=(struct listNode*)malloc(sizeof(struct listNode));
	if(newNode  == NULL){
		printf("Memory Error\n");
		return -1;
	}
	newNode->data=data;
	p=*head;
	if(pos==1 || p==NULL){
		newNode->next=*head;
		*head=newNode;
	}
	else{
		while(p!=NULL && (k<pos)){
			k++;
			q=p;
			p=p->next;
		}
		newNode->next=q->next;
		q->next=newNode;
	}
}
void deleteNodeFromLinkedList(struct listNode **head, int pos){
	int k=1;
	struct listNode *p,*q;
	p=*head;
	if(*head==NULL){
		printf("List Empty\n");
		return;
	}
	else if(pos==1){
		*head=(*head)->next;
		free(p);
	}
	else{
		while(p!=NULL && k<pos){
			k++;
			q=p;
			p=p->next;
		}
		if(p==NULL){
			printf("Position does not exist\n");
		}
		else{
			q->next=p->next;
			free(p);
		}
	}
}
void printSLList(struct listNode *head){
	while(head!=NULL){
		printf("%d ",head->data);
		head=head->next;
	}
	printf("\n");
}
