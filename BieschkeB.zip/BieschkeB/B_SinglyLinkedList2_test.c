/*Brandon Bieschke
ECE 361 - Fall 2021 - HW 2
3b - Rewriting Karumanchi's Singly Linked List

Refactor Karumanchi�s SinglyLinkedList.c to separate the linked list ADT and main() into two files.
Create a header (.h) file for your newly minted linked list ADT.
This is the test.c, which includes the main() and the test call.
*/

#include "B_SinglyLinkedList2.c"

int main() {
    kreatorSLL();

    return 0;
}

void singlyLinkedList_test(struct listNode *head){

	insertInSinglyLinkedList(&head,5,5);

	if (insertInSinglyLinkedList(&head,5,5) == -1)
        printf("test1 - ERROR!!! Failed to create LLL.");
    else
        printf("test1 - Created successfully!\n");

    insertInSinglyLinkedList(&head,2,5);

	if (insertInSinglyLinkedList(&head,2,5) == -1)
        printf("test2 - ERROR!!! Failed to create LLL.");
    else
        printf("test2 - Created successfully!\n");

	insertInSinglyLinkedList(&head,5,10);

	if (insertInSinglyLinkedList(&head,5,10) == -1)
        printf("test3 - ERROR!!! Failed to create LLL.");
    else
        printf("test3 - Created successfully!\n");

   	insertInSinglyLinkedList(&head,7,5);
	if (insertInSinglyLinkedList(&head,7,5) == -1)
        printf("test4 - ERROR!!! Failed to insert in LLL.");
    else
        printf("test4 - Created successfully!\n");

	printf("Elements in List:%d\n",singlyListLength(head));
	printSLList(head);
	deleteNodeFromLinkedList(&head,1);
	printSLList(head);
	//return 0;
}
