/* Brandon Bieschke
ECE 361 - Fall 2021 - HW2
Problem #1 - 5x5 integer array

This is a C application that reads integers from the console into a 5 x 5 array
and then prints the row sums and the column sums.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    int int_array[5][5];
    int row_total, col_total = 0;

    printf("Hello! And Welcome to the Integer array application.\n"
        "We're going to take 5x5 arrays of integers and show the sums of the rows and columns.\n"
        "For example, take the following 5x5 integer array: \n\n"

        "row1: 8 3 9 0 10\n"
        "row2: 3 5 17 1 1\n"
        "row3: 2 8 6 23 1\n"
        "row4: 15 7 3 2 9\n"
        "row5: 6 14 2 6 0\n\n"

        "will result in:\n"
        "Row totals: 30 27 40 36 28\n"
        "Col totals: 34 37 37 32 21\n");

        printf("Make sense? Good! Let's start by having you enter 5 integers, one at a time:\n");

        for (int i = 0; i < 5; i++) {       //iterate through the rows of the array
            for (int j = 0; j < 5; j++) {   //iterate through the columns of the array
                printf("Enter row %d, column %d: ", i+1, j+1 ); //offset by one for readability
                scanf("%d", &int_array[i][j]);
            }
        }

        printf("Great! You entered: \n");   //prints the array entered, separated by rows
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                printf("%d ", int_array[i][j]);
            } printf("\n");
        }

        printf("\n\nRow total: \n");        //prints the total of each row
        for (int i = 0; i < 5; i++) {       //by iterating through each row
            for (int j = 0; j < 5; j++) {   //and each entry in each row
                row_total += int_array[i][j];      //and adding each entry to the sum of the row
            }
            printf("Row%d: %d\n", i+1, row_total);
            row_total = 0;                  //resets the row's total count to 0 for each new column
        }

        printf("\nColumn total: \n");       //prints the total of each column
        for (int j = 0; j < 5; j++) {   //takes the first entry in each column
            col_total = 0;          //resets the columns total count to 0 for each new column
            for (int i = 0; i < 5; i++) {   //and jumps to the same entry in the next row
                col_total += int_array[i][j];   //and adds each entry to the sum of the column
            }
            printf("Col%d: %d\n", j+1, col_total);
        }

    return 0;
}
